import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model for administrators
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  discordId: text("discord_id").notNull().unique(),
  isAdmin: boolean("is_admin").default(false),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

// Troop types enum
export const troopTypes = ["fante", "fanti", "cavallo", "cavalli", "blindo", "blindi", "autoblindo", "dirigibile", "dirigibili", "artiglieria", "artiglierie"] as const;
export const troopTypesEnum = z.enum(troopTypes);

// Nation names and adjectives enum
export const nationNames = [
  "svezia", "svedese", "svedesi",
  "russia", "russo", "russi",
  "germania", "tedesco", "tedeschi", 
  "austria", "austriaco", "austriaci",
  "turchia", "turco", "turchi", 
  "italia", "italiano", "italiani",
  "gran bretagna", "gran bretagna", "britannico", "britannici", 
  "francia", "francese", "francesi",
  "spagna", "spagnolo", "spagnoli", 
  "marocco", "marocchino", "marocchini"
] as const;
export const nationNamesEnum = z.enum(nationNames);

// Main nation enum (standardized names)
export const standardNationNames = ["svezia", "russia", "germania", "austria", "turchia", "italia", "gran bretagna", "francia", "spagna", "marocco"] as const;
export const standardNationNamesEnum = z.enum(standardNationNames);

// Main troop type enum (standardized names)
export const standardTroopTypes = ["fanti", "cavalli", "blindi", "dirigibili", "artiglierie"] as const;
export const standardTroopTypesEnum = z.enum(standardTroopTypes);

// Troop entries table
export const troops = pgTable("troops", {
  id: serial("id").primaryKey(),
  channelId: text("channel_id").notNull(),
  serverId: text("server_id").notNull(),
  troopType: text("troop_type", { enum: standardTroopTypes }).notNull(),
  nation: text("nation", { enum: standardNationNames }).notNull(),
  city: text("city").notNull(),
  quantity: integer("quantity").notNull(),
  updatedAt: text("updated_at").notNull(), // Timestamp as string
  updatedBy: text("updated_by").notNull(), // Discord user ID
});

export const insertTroopSchema = createInsertSchema(troops).omit({
  id: true,
});

// Command logs for undo functionality
export const commandLogs = pgTable("command_logs", {
  id: serial("id").primaryKey(),
  channelId: text("channel_id").notNull(),
  serverId: text("server_id").notNull(),
  command: text("command").notNull(),
  userId: text("user_id").notNull(),
  timestamp: text("timestamp").notNull(),
  affectedData: jsonb("affected_data"),
});

export const insertCommandLogSchema = createInsertSchema(commandLogs).omit({
  id: true,
});

// Admin settings for channels
export const channelAdmins = pgTable("channel_admins", {
  id: serial("id").primaryKey(),
  channelId: text("channel_id").notNull(),
  serverId: text("server_id").notNull(),
  adminId: text("admin_id").notNull(), // Discord user ID
});

export const insertChannelAdminSchema = createInsertSchema(channelAdmins).omit({
  id: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Troop = typeof troops.$inferSelect;
export type InsertTroop = z.infer<typeof insertTroopSchema>;

export type CommandLog = typeof commandLogs.$inferSelect;
export type InsertCommandLog = z.infer<typeof insertCommandLogSchema>;

export type ChannelAdmin = typeof channelAdmins.$inferSelect;
export type InsertChannelAdmin = z.infer<typeof insertChannelAdminSchema>;

// Helper types and functions for mapping variations to standard names
export function standardizeTroopType(type: string): string {
  type = type.toLowerCase();
  if (type === "fante" || type === "fanti") return "fanti";
  if (type === "cavallo" || type === "cavalli") return "cavalli";
  if (type === "blindo" || type === "blindi" || type === "autoblindo") return "blindi";
  if (type === "dirigibile" || type === "dirigibili") return "dirigibili";
  if (type === "artiglieria" || type === "artiglierie") return "artiglierie";
  return type;
}

export function standardizeNation(nation: string): string {
  nation = nation.toLowerCase();
  if (nation === "svedese" || nation === "svedesi") return "svezia";
  if (nation === "russo" || nation === "russi") return "russia";
  if (nation === "tedesco" || nation === "tedeschi") return "germania";
  if (nation === "austriaco" || nation === "austriaci") return "austria";
  if (nation === "turco" || nation === "turchi") return "turchia";
  if (nation === "italiano" || nation === "italiani") return "italia";
  if (nation === "britannico" || nation === "britannici") return "gran bretagna";
  if (nation === "francese" || nation === "francesi") return "francia";
  if (nation === "spagnolo" || nation === "spagnoli") return "spagna";
  if (nation === "marocchino" || nation === "marocchini") return "marocco";
  return nation;
}

// Helper function to get emoji for troop type
export function getTroopEmoji(troopType: string): string {
  const standardType = standardizeTroopType(troopType);
  switch (standardType) {
    case "fanti":
      return "💂";
    case "cavalli":
      return "🐴";
    case "blindi":
      return "🚗";
    case "dirigibili":
      return "🎈";
    case "artiglierie":
      return "💣";
    default:
      return "⚔️";
  }
}

// Helper function to get emoji for nation
export function getNationEmoji(nation: string): string {
  const standardNation = standardizeNation(nation);
  switch (standardNation) {
    case "italia":
      return "🇮🇹";
    case "germania":
      return "🇩🇪";
    case "francia":
      return "🇫🇷";
    case "svezia":
      return "🇸🇪";
    case "russia":
      return "🇷🇺";
    case "austria":
      return "🇦🇹";
    case "turchia":
      return "🇹🇷";
    case "gran bretagna":
      return "🇬🇧";
    case "spagna":
      return "🇪🇸";
    case "marocco":
      return "🇲🇦";
    default:
      return "🏳️";
  }
}
