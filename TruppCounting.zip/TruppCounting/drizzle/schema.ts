import { pgTable, text, serial, integer, jsonb } from "drizzle-orm/pg-core";
import * as schema from "../shared/schema";

// Export all schema tables
export const users = schema.users;
export const troops = schema.troops;
export const commandLogs = schema.commandLogs;
export const channelAdmins = schema.channelAdmins;