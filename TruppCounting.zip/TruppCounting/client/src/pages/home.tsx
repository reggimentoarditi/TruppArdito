import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("system");
  const [commandInput, setCommandInput] = useState("");
  const [messages, setMessages] = useState<{
    sender: string;
    content: string;
    type: 'user' | 'bot';
    status?: 'success' | 'info' | 'error' | 'warning';
    timestamp: string;
  }[]>([]);

  // Fetch bot status
  const { data: statusData, isLoading: isStatusLoading } = useQuery({
    queryKey: ['/api/status'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Function to handle sending commands
  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commandInput.trim()) return;

    // Add user message
    addMessage('Ardito', commandInput, 'user');
    
    // Process command (simulated as this would normally be handled by the bot)
    processCommand(commandInput);
    
    // Clear input
    setCommandInput("");
  };

  // Function to add a message to the chat
  const addMessage = (sender: string, content: string, type: 'user' | 'bot', status?: 'success' | 'info' | 'error' | 'warning') => {
    const now = new Date();
    const timestamp = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    setMessages(prev => [...prev, { sender, content, type, status, timestamp }]);
    
    // Scroll to bottom on next render
    setTimeout(() => {
      const messagesDiv = document.getElementById('messages-list');
      if (messagesDiv) {
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
      }
    }, 10);
  };

  // Function to handle clicking on command examples
  const handleCommandExample = (command: string) => {
    setCommandInput(command);
    // Focus input field
    const inputElement = document.getElementById('command-input') as HTMLInputElement;
    if (inputElement) {
      inputElement.focus();
    }
  };

  // Simulate command processing (this would connect to the actual bot in production)
  const processCommand = (command: string) => {
    // This is just a simulation for UI demonstration
    // In production, commands would be handled by the Discord bot
    
    const commandLower = command.toLowerCase();
    const commandParts = commandLower.split(" ");
    const commandType = commandParts[0];
    
    let response = '';
    let emoji = '';
    let status: 'success' | 'error' | 'info' | 'warning' = 'info';
    
    setTimeout(() => {
      switch(commandType) {
        case '!start':
          response = '👋 Buongiorno Ardito! "Nel combattimento, nulla è impossibile per chi ha coraggio!" - Motto degli Arditi';
          emoji = '✅';
          status = 'success';
          break;
        case '!info':
          response = 'Ecco la lista dei comandi disponibili. Usa !help [comando] per dettagli specifici.';
          emoji = 'ℹ️';
          status = 'info';
          break;
        case '!stato':
          response = `TruppArdito è ${statusData?.bot?.online ? 'online' : 'offline'}! ${statusData?.database?.connected ? 'Connessione al database attiva.' : 'Database non connesso.'} Latenza: ${statusData?.bot?.latency || 'N/A'}ms`;
          emoji = '✅';
          status = 'success';
          break;
        case '!entra':
          if (commandParts.length >= 5) {
            response = `Ho aggiunto ${commandParts[1]} ${getTroopEmoji(commandParts[2])} ${commandParts[2]} della ${getNationEmoji(commandParts[3])} ${commandParts[3]} a ${commandParts.slice(4).join(' ')}.`;
            emoji = '👍🏻';
            status = 'success';
          } else {
            response = 'Comando non valido. Uso corretto: !entra [quantità] [tipo truppa] [nazione] [città]';
            emoji = '❓';
            status = 'error';
          }
          break;
        default:
          response = 'Comando non riconosciuto. Questo è un simulatore UI e non è connesso al vero bot Discord. Utilizza il bot Discord per funzionalità complete.';
          emoji = '👎🏻';
          status = 'error';
      }
      
      addMessage('TruppArdito', `${emoji} ${response}`, 'bot', status);
    }, 500);
  };

  // Add welcome message when component mounts
  if (messages.length === 0) {
    setTimeout(() => {
      addMessage('TruppArdito', '✅ Benvenuto al simulatore dell\'interfaccia di TruppArdito! Questa è una dimostrazione visiva del bot. Per utilizzare il bot reale, aggiungilo al tuo server Discord.', 'bot', 'success');
    }, 1000);
  }

  // Helper functions for emoji display
  function getTroopEmoji(troopType: string) {
    troopType = troopType.toLowerCase();
    if (troopType.includes('fant')) return '💂';
    if (troopType.includes('cavall')) return '🐴';
    if (troopType.includes('blind') || troopType.includes('auto')) return '🚗';
    if (troopType.includes('dirigibil')) return '🎈';
    if (troopType.includes('artiglieri')) return '💣';
    return '⚔️';
  }

  function getNationEmoji(nation: string) {
    nation = nation.toLowerCase();
    if (nation.includes('italia') || nation.includes('italian')) return '🇮🇹';
    if (nation.includes('german') || nation.includes('tedesc')) return '🇩🇪';
    if (nation.includes('franc') || nation.includes('frances')) return '🇫🇷';
    if (nation.includes('svezia') || nation.includes('svedes')) return '🇸🇪';
    if (nation.includes('russia') || nation.includes('russ')) return '🇷🇺';
    if (nation.includes('austria') || nation.includes('austriac')) return '🇦🇹';
    if (nation.includes('turchia') || nation.includes('turc')) return '🇹🇷';
    if (nation.includes('gran bretagna') || nation.includes('britannic') || nation.includes('ingles')) return '🇬🇧';
    if (nation.includes('spagna') || nation.includes('spagnol')) return '🇪🇸';
    if (nation.includes('marocco') || nation.includes('marocchi')) return '🇲🇦';
    return '🏳️';
  }

  return (
    <div className="bg-neutral-200 text-neutral-800 font-sans min-h-screen">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <header className="mb-8">
          <div className="flex flex-col md:flex-row items-center justify-between bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="flex items-center mb-4 md:mb-0">
              <div className="bg-accent rounded-full p-3 mr-4">
                <span className="text-white text-2xl">🎖️</span>
              </div>
              <div>
                <h1 className="text-3xl font-bold font-heading text-neutral-800">TruppArdito</h1>
                <p className="text-neutral-600">Gestione Truppe per Supremacy 1914</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button
                variant={statusData?.bot?.online ? "default" : "destructive"}
                className="flex items-center"
              >
                <span className="mr-2">●</span>
                {statusData?.bot?.online ? "Online" : "Offline"}
              </Button>
              <Button variant="outline" onClick={() => toast({ title: "Aiuto", description: "Per utilizzare TruppArdito, aggiungi il bot al tuo server Discord e usa i comandi disponibili nella chat." })}>
                Aiuto
              </Button>
            </div>
          </div>
        </header>

        <main className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Command Reference */}
          <section className="lg:col-span-1 order-2 lg:order-1">
            <Card>
              <div className="bg-neutral-800 text-white p-4">
                <h2 className="text-xl font-bold font-heading">🎖️ Comandi Disponibili</h2>
              </div>
              
              <Tabs defaultValue="system" value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-2 w-full">
                  <TabsTrigger value="system">🔴 Controllo Sistema</TabsTrigger>
                  <TabsTrigger value="troops">🟠 Gestione Truppe</TabsTrigger>
                </TabsList>
                
                <TabsContent value="system" className="p-4">
                  <ul className="space-y-3">
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!stato')}>
                      <span className="font-mono text-accent">!stato</span> - Verifica lo stato del bot
                    </li>
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!start')}>
                      <span className="font-mono text-accent">!start</span> - Avvia il bot con un saluto
                    </li>
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!info')}>
                      <span className="font-mono text-accent">!info</span> - Mostra la lista dei comandi
                    </li>
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!annulla')}>
                      <span className="font-mono text-accent">!annulla</span> - Annulla l'ultimo comando
                    </li>
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!stop')}>
                      <span className="font-mono text-accent">!stop</span> - Riavvia il bot (solo admin)
                    </li>
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!admin')}>
                      <span className="font-mono text-accent">!admin</span> - Gestisce gli amministratori del bot
                    </li>
                  </ul>
                </TabsContent>
                
                <TabsContent value="troops" className="p-4">
                  <ul className="space-y-3">
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!entra 10 fanti italia roma')}>
                      <span className="font-mono text-accent">!entra</span> - Registra l'ingresso di truppe
                    </li>
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!esci 5 cavalli francia parigi')}>
                      <span className="font-mono text-accent">!esci</span> - Registra l'uscita di truppe
                    </li>
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!sposta 3 blindi germania berlino monaco')}>
                      <span className="font-mono text-accent">!sposta</span> - Sposta truppe tra città
                    </li>
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!svuota roma')}>
                      <span className="font-mono text-accent">!svuota</span> - Rimuove tutte le truppe da una città
                    </li>
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!totale roma')}>
                      <span className="font-mono text-accent">!totale</span> - Mostra truppe in una città
                    </li>
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!totalenazione italia')}>
                      <span className="font-mono text-accent">!totalenazione</span> - Mostra truppe di una nazione
                    </li>
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!lista')}>
                      <span className="font-mono text-accent">!lista</span> - Mostra l'elenco delle città
                    </li>
                    <li className="p-3 bg-neutral-100 rounded hover:bg-neutral-200 transition cursor-pointer" onClick={() => handleCommandExample('!azzera')}>
                      <span className="font-mono text-accent">!azzera</span> - Azzera tutti i dati (solo admin)
                    </li>
                  </ul>
                </TabsContent>
              </Tabs>
              

            </Card>
            
            <Card className="mt-6">
              <div className="bg-neutral-800 text-white p-4">
                <h2 className="text-xl font-bold font-heading">🔍 Riferimento Rapido</h2>
              </div>
              
              <CardContent className="p-4">
                <h3 className="font-bold mb-2">Tipologie di Truppe:</h3>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">💂</span> Fanti
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🐴</span> Cavalli
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🚗</span> Blindi
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🎈</span> Dirigibili
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">💣</span> Artiglierie
                  </div>
                </div>
                
                <h3 className="font-bold mt-4 mb-2">Nazioni:</h3>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🇮🇹</span> Italia
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🇩🇪</span> Germania
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🇫🇷</span> Francia
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🇬🇧</span> Gran Bretagna
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🇪🇸</span> Spagna
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🇷🇺</span> Russia
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🇦🇹</span> Austria
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🇹🇷</span> Turchia
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🇸🇪</span> Svezia
                  </div>
                  <div className="flex items-center p-2 bg-neutral-100 rounded">
                    <span className="text-xl mr-2">🇲🇦</span> Marocco
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>
          
          {/* Right Column - Chat Simulator */}
          <section className="lg:col-span-2 order-1 lg:order-2">
            <Card className="h-[600px] flex flex-col">
              <div className="bg-neutral-800 text-white p-4">
                <h2 className="text-xl font-bold font-heading">💬 Simulatore Chat Discord</h2>
              </div>
              
              <div id="messages-list" className="flex-1 overflow-y-auto p-4 bg-neutral-100 space-y-4">
                {messages.map((msg, idx) => (
                  <div 
                    key={idx} 
                    className={`flex items-start mb-4 ${msg.type === 'bot' ? 'justify-start' : 'justify-end'}`}
                  >
                    {msg.type === 'user' ? (
                      <div className="ml-auto">
                        <div className="flex items-end">
                          <div className="bg-neutral-700 text-white rounded-lg py-2 px-4 max-w-md">
                            <p className="font-mono">{msg.content}</p>
                          </div>
                          <div className="ml-2 mb-1 text-xs text-neutral-500">{msg.timestamp}</div>
                        </div>
                        <div className="text-right text-xs text-neutral-500 mt-1">{msg.sender}</div>
                      </div>
                    ) : (
                      <div className="mr-auto">
                        <div className="flex items-end">
                          <div className="bg-neutral-800 text-white rounded-full w-8 h-8 flex items-center justify-center mr-2">
                            🎖️
                          </div>
                          <div className={`bg-white border-l-4 rounded-lg py-2 px-4 max-w-md ${
                            msg.status === 'success' ? 'border-success' :
                            msg.status === 'error' ? 'border-error' :
                            msg.status === 'warning' ? 'border-warning' :
                            'border-accent'
                          }`}>
                            <p dangerouslySetInnerHTML={{ __html: msg.content.replace(/\n/g, '<br>') }}></p>
                          </div>
                          <div className="ml-2 mb-1 text-xs text-neutral-500">{msg.timestamp}</div>
                        </div>
                        <div className="text-left text-xs text-neutral-500 mt-1 ml-10">{msg.sender}</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              
              <div className="p-4 border-t border-neutral-300 bg-white">
                <form className="flex" onSubmit={handleCommandSubmit}>
                  <Input 
                    id="command-input" 
                    type="text" 
                    placeholder="Digita un comando (es: !info)" 
                    className="flex-1 rounded-r-none"
                    value={commandInput}
                    onChange={(e) => setCommandInput(e.target.value)}
                  />
                  <Button 
                    type="submit" 
                    className="bg-accent hover:bg-accent/90 rounded-l-none"
                  >
                    Invia
                  </Button>
                </form>
              </div>
            </Card>
            
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <div className="bg-neutral-800 text-white p-4">
                  <h2 className="text-xl font-bold font-heading">📊 Statistiche Sistema</h2>
                </div>
                <CardContent className="p-4">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium text-neutral-500">Stato Bot</h3>
                      <p className="text-lg font-medium flex items-center mt-1">
                        <span className={`h-3 w-3 rounded-full mr-2 ${statusData?.bot?.online ? 'bg-success' : 'bg-error'}`}></span>
                        {statusData?.bot?.online ? 'Online' : 'Offline'}
                      </p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-neutral-500">Database</h3>
                      <p className="text-lg font-medium flex items-center mt-1">
                        <span className={`h-3 w-3 rounded-full mr-2 ${statusData?.database?.connected ? 'bg-success' : 'bg-error'}`}></span>
                        {statusData?.database?.connected ? 'Connesso' : 'Non connesso'}
                      </p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-neutral-500">Latenza</h3>
                      <p className="text-lg font-medium mt-1">{statusData?.bot?.latency || 'N/A'}ms</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-neutral-500">Versione</h3>
                      <p className="text-lg font-medium mt-1">{statusData?.version || '1.0.0'}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <div className="bg-neutral-800 text-white p-4">
                  <h2 className="text-xl font-bold font-heading">🛠️ Risorse Admin</h2>
                </div>
                <CardContent className="p-4">
                  <div className="space-y-4">
                    <Button 
                      variant="default" 
                      className="w-full bg-neutral-700 hover:bg-neutral-600"
                      onClick={() => handleCommandExample('!admin')}
                    >
                      <span className="mr-2">🔐</span> Pannello Amministratore
                    </Button>
                    <Button 
                      variant="outline" 
                      className="w-full" 
                      onClick={() => handleCommandExample('!stato')}
                    >
                      <span className="mr-2">📡</span> Verifica Stato
                    </Button>
                    <Button 
                      variant="destructive" 
                      className="w-full" 
                      onClick={() => handleCommandExample('!azzera')}
                    >
                      <span className="mr-2">🗑️</span> Azzeramento Dati
                    </Button>
                    <Button 
                      variant="default" 
                      className="w-full bg-warning hover:bg-warning/90" 
                      onClick={() => handleCommandExample('!stop')}
                    >
                      <span className="mr-2">🔄</span> Riavvia Bot
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </section>
        </main>
        
        <footer className="mt-12 text-center text-neutral-600 border-t border-neutral-300 pt-6">
          <p>TruppArdito - Bot Discord per Supremacy 1914</p>
          <p className="text-sm mt-2">© {new Date().getFullYear()} - Sviluppato con tecnologie Discord API e Node.js</p>
        </footer>
      </div>
    </div>
  );
}
