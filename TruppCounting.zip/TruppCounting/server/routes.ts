import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { initializeBot, getBotStatus, shutdownBot } from "./discord/bot";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

const apiErrorHandler = (err: any, res: Response) => {
  console.error("API Error:", err);
  
  if (err instanceof z.ZodError) {
    return res.status(400).json({ 
      error: "Validation error", 
      details: fromZodError(err).message 
    });
  }
  
  return res.status(500).json({ 
    error: "Internal server error", 
    message: err.message 
  });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize Discord bot
  const botClient = await initializeBot();
  
  // API route to check bot status
  app.get("/api/status", async (req: Request, res: Response) => {
    try {
      const status = getBotStatus();
      const dbStatus = await storage.checkDatabaseConnection();
      
      res.json({
        bot: {
          online: status.online,
          latency: status.latency,
        },
        database: {
          connected: dbStatus,
        },
        version: "1.0.0",
      });
    } catch (err) {
      apiErrorHandler(err, res);
    }
  });

  // API route to get all cities for a channel
  app.get("/api/cities", async (req: Request, res: Response) => {
    try {
      const { channelId, serverId } = req.query;
      
      if (!channelId || !serverId) {
        return res.status(400).json({ 
          error: "Missing parameters", 
          message: "channelId and serverId are required" 
        });
      }
      
      const cities = await storage.getAllCities(
        channelId as string,
        serverId as string
      );
      
      res.json({ cities });
    } catch (err) {
      apiErrorHandler(err, res);
    }
  });

  // API route to get troops for a city
  app.get("/api/troops/city/:city", async (req: Request, res: Response) => {
    try {
      const { city } = req.params;
      const { channelId, serverId } = req.query;
      
      if (!channelId || !serverId) {
        return res.status(400).json({ 
          error: "Missing parameters", 
          message: "channelId and serverId are required" 
        });
      }
      
      const troops = await storage.getTroopsByCity(
        channelId as string,
        serverId as string,
        city
      );
      
      res.json({ troops });
    } catch (err) {
      apiErrorHandler(err, res);
    }
  });

  // API route to get troops for a nation
  app.get("/api/troops/nation/:nation", async (req: Request, res: Response) => {
    try {
      const { nation } = req.params;
      const { channelId, serverId } = req.query;
      
      if (!channelId || !serverId) {
        return res.status(400).json({ 
          error: "Missing parameters", 
          message: "channelId and serverId are required" 
        });
      }
      
      const troops = await storage.getTroopsByNation(
        channelId as string,
        serverId as string,
        nation
      );
      
      res.json({ troops });
    } catch (err) {
      apiErrorHandler(err, res);
    }
  });

  // API route to get channel admins
  app.get("/api/admins", async (req: Request, res: Response) => {
    try {
      const { channelId, serverId } = req.query;
      
      if (!channelId || !serverId) {
        return res.status(400).json({ 
          error: "Missing parameters", 
          message: "channelId and serverId are required" 
        });
      }
      
      const admins = await storage.getChannelAdmins(
        channelId as string,
        serverId as string
      );
      
      res.json({ admins });
    } catch (err) {
      apiErrorHandler(err, res);
    }
  });

  // Setup HTTP server
  const httpServer = createServer(app);

  // Handle application shutdown
  process.on('SIGINT', async () => {
    console.log('Shutting down...');
    await shutdownBot();
    process.exit(0);
  });

  return httpServer;
}
