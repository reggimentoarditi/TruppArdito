import {
  User,
  InsertUser,
  Troop,
  InsertTroop,
  CommandLog,
  InsertCommandLog,
  ChannelAdmin,
  InsertChannelAdmin,
  standardTroopTypes,
  standardNationNames
} from '@shared/schema';
import { IStorage } from './storage';
import { db } from './db';
import { eq, and, desc, sql } from 'drizzle-orm';
import {
  users,
  troops,
  commandLogs,
  channelAdmins
} from '@shared/schema';

// PostgreSQL storage implementation for TruppArdito bot
export class DatabaseStorage implements IStorage {
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.id, id));
    return results.length > 0 ? results[0] : undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const results = await db.select().from(users).where(eq(users.username, username));
    return results.length > 0 ? results[0] : undefined;
  }

  async createUser(user: InsertUser): Promise<User> {
    const results = await db.insert(users).values(user).returning();
    return results[0];
  }
  
  // Troop operations
  async addTroops(troop: InsertTroop): Promise<void> {
    // Standardize troop type and nation to ensure they match the enum values
    const standardTroop = {
      ...troop,
      troopType: standardTroopTypes.includes(troop.troopType as any) 
        ? troop.troopType 
        : 'fanti',
      nation: standardNationNames.includes(troop.nation as any)
        ? troop.nation
        : 'italia'
    };
    
    // Check if troops already exist
    const existingTroops = await db.select()
      .from(troops)
      .where(
        and(
          eq(troops.channelId, troop.channelId),
          eq(troops.serverId, troop.serverId),
          eq(troops.troopType, standardTroop.troopType as any),
          eq(troops.nation, standardTroop.nation as any),
          eq(troops.city, troop.city)
        )
      );
    
    if (existingTroops.length > 0) {
      // Update existing troops
      await db.update(troops)
        .set({
          quantity: existingTroops[0].quantity + troop.quantity,
          updatedAt: troop.updatedAt,
          updatedBy: troop.updatedBy
        })
        .where(eq(troops.id, existingTroops[0].id));
    } else {
      // Insert new troops
      await db.insert(troops).values(standardTroop);
    }
  }

  async removeTroops(
    channelId: string,
    serverId: string,
    troopType: string,
    nation: string,
    city: string,
    quantity: number,
    userId: string
  ): Promise<void> {
    // Standardize inputs
    const standardTroopType = standardTroopTypes.includes(troopType as any) 
      ? troopType 
      : 'fanti';
    
    const standardNation = standardNationNames.includes(nation as any)
      ? nation
      : 'italia';
    
    // Get existing troops
    const existingTroops = await db.select()
      .from(troops)
      .where(
        and(
          eq(troops.channelId, channelId),
          eq(troops.serverId, serverId),
          eq(troops.troopType, standardTroopType as any),
          eq(troops.nation, standardNation as any),
          eq(troops.city, city)
        )
      );
    
    if (existingTroops.length === 0) {
      throw new Error(`Non ci sono truppe di tipo ${troopType} della nazione ${nation} nella città ${city}`);
    }
    
    const existingTroop = existingTroops[0];
    
    if (existingTroop.quantity < quantity) {
      throw new Error(`Non ci sono abbastanza truppe di tipo ${troopType} della nazione ${nation} nella città ${city}. Attualmente ce ne sono ${existingTroop.quantity}`);
    }
    
    if (existingTroop.quantity - quantity <= 0) {
      // Remove all troops
      await db.delete(troops).where(eq(troops.id, existingTroop.id));
    } else {
      // Update quantity
      await db.update(troops)
        .set({
          quantity: existingTroop.quantity - quantity,
          updatedAt: new Date().toISOString(),
          updatedBy: userId
        })
        .where(eq(troops.id, existingTroop.id));
    }
  }

  async moveTroops(
    channelId: string,
    serverId: string,
    troopType: string,
    nation: string,
    sourceCity: string,
    destCity: string,
    quantity: number,
    userId: string
  ): Promise<void> {
    // Remove from source
    await this.removeTroops(
      channelId,
      serverId,
      troopType,
      nation,
      sourceCity,
      quantity,
      userId
    );
    
    // Add to destination
    await this.addTroops({
      channelId,
      serverId,
      troopType: troopType as any,
      nation: nation as any,
      city: destCity,
      quantity,
      updatedAt: new Date().toISOString(),
      updatedBy: userId
    });
  }

  async clearCity(
    channelId: string,
    serverId: string,
    city: string,
    userId: string
  ): Promise<void> {
    await db.delete(troops)
      .where(
        and(
          eq(troops.channelId, channelId),
          eq(troops.serverId, serverId),
          eq(troops.city, city)
        )
      );
  }

  async getTroopsByCity(
    channelId: string,
    serverId: string,
    city: string
  ): Promise<Troop[]> {
    return db.select()
      .from(troops)
      .where(
        and(
          eq(troops.channelId, channelId),
          eq(troops.serverId, serverId),
          eq(troops.city, city.toLowerCase())
        )
      );
  }

  async getTroopsByNation(
    channelId: string,
    serverId: string,
    nation: string
  ): Promise<Troop[]> {
    // Standardize nation
    const standardNation = standardNationNames.includes(nation as any)
      ? nation
      : 'italia';
      
    return db.select()
      .from(troops)
      .where(
        and(
          eq(troops.channelId, channelId),
          eq(troops.serverId, serverId),
          eq(troops.nation, standardNation as any)
        )
      );
  }

  async getTroopsByTypeNationCity(
    channelId: string,
    serverId: string,
    troopType: string,
    nation: string,
    city: string
  ): Promise<Troop | undefined> {
    // Standardize inputs
    const standardTroopType = standardTroopTypes.includes(troopType as any) 
      ? troopType 
      : 'fanti';
    
    const standardNation = standardNationNames.includes(nation as any)
      ? nation
      : 'italia';
    
    const results = await db.select()
      .from(troops)
      .where(
        and(
          eq(troops.channelId, channelId),
          eq(troops.serverId, serverId),
          eq(troops.troopType, standardTroopType as any),
          eq(troops.nation, standardNation as any),
          eq(troops.city, city.toLowerCase())
        )
      );
    
    return results.length > 0 ? results[0] : undefined;
  }

  async getAllCities(
    channelId: string,
    serverId: string
  ): Promise<string[]> {
    const result = await db.select({ city: troops.city })
      .from(troops)
      .where(
        and(
          eq(troops.channelId, channelId),
          eq(troops.serverId, serverId)
        )
      )
      .groupBy(troops.city);
    
    return result.map(row => row.city);
  }

  async clearTroopsForChannel(
    channelId: string,
    serverId: string
  ): Promise<void> {
    await db.delete(troops)
      .where(
        and(
          eq(troops.channelId, channelId),
          eq(troops.serverId, serverId)
        )
      );
  }

  // Command log operations
  async logCommand(log: InsertCommandLog): Promise<void> {
    await db.insert(commandLogs).values(log);
  }

  async updateLastCommandLog(
    channelId: string,
    serverId: string,
    userId: string,
    affectedData: any
  ): Promise<void> {
    const results = await db.select()
      .from(commandLogs)
      .where(
        and(
          eq(commandLogs.channelId, channelId),
          eq(commandLogs.serverId, serverId),
          eq(commandLogs.userId, userId)
        )
      )
      .orderBy(desc(commandLogs.timestamp))
      .limit(1);
    
    if (results.length > 0) {
      await db.update(commandLogs)
        .set({ affectedData })
        .where(eq(commandLogs.id, results[0].id));
    }
  }

  async getLastCommandLogs(
    channelId: string,
    serverId: string,
    count: number
  ): Promise<CommandLog[]> {
    return db.select()
      .from(commandLogs)
      .where(
        and(
          eq(commandLogs.channelId, channelId),
          eq(commandLogs.serverId, serverId)
        )
      )
      .orderBy(desc(commandLogs.timestamp))
      .limit(count);
  }

  // Admin operations
  async addChannelAdmin(admin: InsertChannelAdmin): Promise<void> {
    await db.insert(channelAdmins).values(admin);
  }

  async removeChannelAdmin(
    channelId: string,
    serverId: string,
    adminId: string
  ): Promise<void> {
    await db.delete(channelAdmins)
      .where(
        and(
          eq(channelAdmins.channelId, channelId),
          eq(channelAdmins.serverId, serverId),
          eq(channelAdmins.adminId, adminId)
        )
      );
  }

  async getChannelAdmins(
    channelId: string,
    serverId: string
  ): Promise<ChannelAdmin[]> {
    return db.select()
      .from(channelAdmins)
      .where(
        and(
          eq(channelAdmins.channelId, channelId),
          eq(channelAdmins.serverId, serverId)
        )
      );
  }

  // Undo operations
  async undoTroopAddition(
    channelId: string,
    serverId: string,
    data: any
  ): Promise<string> {
    try {
      if (!data || !data.troopType || !data.nation || !data.city || !data.quantity) {
        return "Dati insufficienti per annullare l'aggiunta";
      }
      
      // Remove the troops that were added
      await this.removeTroops(
        channelId,
        serverId,
        data.troopType,
        data.nation,
        data.city,
        data.quantity,
        "undo-system"
      );
      
      return "Aggiunta annullata con successo";
    } catch (error) {
      return `Errore: ${(error as Error).message}`;
    }
  }

  async undoTroopRemoval(
    channelId: string,
    serverId: string,
    data: any
  ): Promise<string> {
    try {
      if (!data || !data.troopType || !data.nation || !data.city || !data.quantity) {
        return "Dati insufficienti per annullare la rimozione";
      }
      
      // Add back the troops that were removed
      await this.addTroops({
        channelId,
        serverId,
        troopType: data.troopType as any,
        nation: data.nation as any,
        city: data.city,
        quantity: data.quantity,
        updatedAt: new Date().toISOString(),
        updatedBy: "undo-system"
      });
      
      return "Rimozione annullata con successo";
    } catch (error) {
      return `Errore: ${(error as Error).message}`;
    }
  }

  async undoTroopMovement(
    channelId: string,
    serverId: string,
    data: any
  ): Promise<string> {
    try {
      if (!data || !data.troopType || !data.nation || !data.sourceCity || !data.destCity || !data.quantity) {
        return "Dati insufficienti per annullare lo spostamento";
      }
      
      // Move troops back from destination to source
      await this.moveTroops(
        channelId,
        serverId,
        data.troopType,
        data.nation,
        data.destCity,  // Now the source is the previous destination
        data.sourceCity, // Now the destination is the previous source
        data.quantity,
        "undo-system"
      );
      
      return "Spostamento annullato con successo";
    } catch (error) {
      return `Errore: ${(error as Error).message}`;
    }
  }

  async undoCityClearing(
    channelId: string,
    serverId: string,
    data: any
  ): Promise<string> {
    try {
      if (!data || !data.city || !data.troops || !Array.isArray(data.troops)) {
        return "Dati insufficienti per annullare lo svuotamento";
      }
      
      // Add back all troops that were in the city
      for (const troop of data.troops) {
        await this.addTroops({
          channelId,
          serverId,
          troopType: troop.troopType as any,
          nation: troop.nation as any,
          city: troop.city,
          quantity: troop.quantity,
          updatedAt: new Date().toISOString(),
          updatedBy: "undo-system"
        });
      }
      
      return "Svuotamento annullato con successo";
    } catch (error) {
      return `Errore: ${(error as Error).message}`;
    }
  }

  // System operations
  async checkDatabaseConnection(): Promise<boolean> {
    try {
      // Test database connection with a simple query
      await db.execute(sql`SELECT 1`);
      return true;
    } catch (error) {
      console.error('Database connection check failed:', error);
      return false;
    }
  }
}