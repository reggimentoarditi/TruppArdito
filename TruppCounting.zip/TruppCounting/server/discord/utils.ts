import { storage } from '../storage';

// Collection of motivational quotes from Italian Arditi
const ARDITI_QUOTES = [
  "Nel combattimento, nulla è impossibile per chi ha coraggio!",
  "Meglio vivere un giorno da leone che cento anni da pecora.",
  "Il coraggio è la virtù dei forti, la prudenza quella dei saggi.",
  "La gloria non si conquista con le parole, ma con i fatti.",
  "Chi osa vince!",
  "Ardisco non ordisco.",
  "Non c'è vittoria senza sacrificio.",
  "La disciplina è l'anima di un esercito.",
  "L'audacia è la prima qualità di un comandante.",
  "La volontà di vincere è già mezza vittoria.",
  "Nessun ostacolo è insormontabile per un animo deciso.",
  "Il valore del soldato sta nel cuore, non nell'arma.",
  "Chi ha paura resta indietro, chi ha coraggio avanza.",
  "La vittoria appartiene ai tenaci.",
  "L'onore è il premio del dovere compiuto."
];

// Format a motivational quote
export function formatMotivationalQuote(): string {
  const randomIndex = Math.floor(Math.random() * ARDITI_QUOTES.length);
  return `"${ARDITI_QUOTES[randomIndex]}" - Motto degli Arditi`;
}

// Get time of day greeting
export function getTimeOfDay(): string {
  const hour = new Date().getHours();
  
  if (hour >= 5 && hour < 12) {
    return 'Buongiorno';
  } else if (hour >= 12 && hour < 18) {
    return 'Buon pomeriggio';
  } else {
    return 'Buonasera';
  }
}

// Check if a user is an admin
export async function isAdmin(
  userId: string, 
  channelId: string, 
  serverId: string
): Promise<boolean> {
  // Bot owner is always admin
  if (process.env.BOT_OWNER_ID && userId === process.env.BOT_OWNER_ID) {
    return true;
  }
  
  // Check if user is in the channel admins
  const admins = await storage.getChannelAdmins(channelId, serverId);
  return admins.some(admin => admin.adminId === userId);
}

// Parse command arguments with awareness of quoted strings
export function parseArgs(input: string): string[] {
  const args: string[] = [];
  let currentArg = '';
  let inQuotes = false;
  
  for (let i = 0; i < input.length; i++) {
    const char = input[i];
    
    if (char === '"' || char === "'") {
      inQuotes = !inQuotes;
      continue;
    }
    
    if (char === ' ' && !inQuotes) {
      if (currentArg) {
        args.push(currentArg);
        currentArg = '';
      }
      continue;
    }
    
    currentArg += char;
  }
  
  if (currentArg) {
    args.push(currentArg);
  }
  
  return args;
}
