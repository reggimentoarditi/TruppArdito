import { Message, EmbedBuilder, MessageReaction } from 'discord.js';
import { 
  standardizeTroopType, 
  standardizeNation, 
  getTroopEmoji, 
  getNationEmoji,
  standardTroopTypesEnum,
  standardNationNamesEnum
} from '@shared/schema';
import { storage } from '../storage';
import { formatMotivationalQuote, getTimeOfDay, isAdmin } from './utils';

// Command handler
export async function handleCommand(message: Message) {
  const content = message.content.trim();
  const commandParts = content.split(' ');
  const command = commandParts[0].toLowerCase();
  
  // Log the command for undo functionality
  const shouldLog = ['!entra', '!esci', '!sposta', '!svuota'].includes(command);
  if (shouldLog) {
    await storage.logCommand({
      channelId: message.channelId,
      serverId: message.guildId || 'DM',
      command: content,
      userId: message.author.id,
      timestamp: new Date().toISOString(),
      affectedData: null // Will be updated by the command handlers
    });
  }

  // Handle different commands
  switch (command) {
    case '!stato':
      await commandStatus(message);
      break;
    case '!start':
      await commandStart(message);
      break;
    case '!info':
      await commandInfo(message);
      break;
    case '!annulla':
      await commandAnnulla(message, commandParts);
      break;
    case '!stop':
      await commandStop(message);
      break;
    case '!entra':
      await commandEntra(message, commandParts);
      break;
    case '!esci':
      await commandEsci(message, commandParts);
      break;
    case '!sposta':
      await commandSposta(message, commandParts);
      break;
    case '!svuota':
      await commandSvuota(message, commandParts);
      break;
    case '!totale':
      await commandTotale(message, commandParts);
      break;
    case '!totalenazione':
      await commandTotaleNazione(message, commandParts);
      break;
    case '!lista':
      await commandLista(message);
      break;
    case '!azzera':
      await commandAzzera(message);
      break;
    case '!admin':
      await commandAdmin(message);
      break;
    case '!test':
    case '!ping':
      await commandPing(message);
      break;
    default:
      await message.react('❓');
      await message.reply('Comando non riconosciuto. Usa !info per vedere la lista dei comandi disponibili.');
      break;
  }
}

// !stato - Check bot status
async function commandStatus(message: Message) {
  try {
    const dbStatus = await storage.checkDatabaseConnection();
    const embed = new EmbedBuilder()
      .setTitle('📊 Stato TruppArdito')
      .setColor('#48BB78')
      .addFields(
        { name: 'Bot', value: '✅ Online', inline: true },
        { name: 'Database', value: dbStatus ? '✅ Connesso' : '❌ Non connesso', inline: true },
        { name: 'Latenza', value: `${message.client.ws.ping}ms`, inline: true },
        { name: 'Versione', value: '1.0.0', inline: true }
      )
      .setFooter({ text: 'TruppArdito - Bot per Supremacy 1914' })
      .setTimestamp();

    await message.reply({ embeds: [embed] });
    await message.react('✅');
  } catch (error) {
    console.error('Error in status command:', error);
    await message.react('👎🏻');
    await message.reply('Si è verificato un errore durante il controllo dello stato.');
  }
}

// !start - Start the bot with a greeting
async function commandStart(message: Message) {
  try {
    const timeOfDay = getTimeOfDay();
    const quote = formatMotivationalQuote();
    
    await message.reply(`👋 ${timeOfDay} ${message.author}! ${quote}`);
    await message.react('👍🏻');
  } catch (error) {
    console.error('Error in start command:', error);
    await message.react('👎🏻');
  }
}

// !info - Show command list
async function commandInfo(message: Message) {
  try {
    const embed = new EmbedBuilder()
      .setTitle('🎖️ TruppArdito - Comandi Disponibili')
      .setColor('#4A5568')
      .setDescription('Ecco la lista dei comandi disponibili:')
      .addFields(
        { 
          name: '🔴 Controllo Sistema',
          value: 
            '`!stato` - Verifica lo stato del bot\n' +
            '`!start` - Avvia il bot con un saluto\n' +
            '`!info` - Mostra questa lista di comandi\n' +
            '`!annulla` - Annulla l\'ultimo comando\n' +
            '`!stop` - Riavvia il bot (solo admin)'
        },
        { 
          name: '🟠 Gestione Truppe',
          value: 
            '`!entra` - Registra l\'ingresso di truppe\n' +
            '`!esci` - Registra l\'uscita di truppe\n' +
            '`!sposta` - Sposta truppe tra città\n' +
            '`!svuota` - Rimuove tutte le truppe da una città\n' +
            '`!totale` - Mostra truppe in una città\n' +
            '`!totalenazione` - Mostra truppe di una nazione\n' +
            '`!lista` - Mostra l\'elenco delle città\n' +
            '`!azzera` - Azzera tutti i dati (solo admin e amministratori server)'
        }
      )
      .setFooter({ text: 'TruppArdito - Bot per Supremacy 1914' });
      
    await message.reply({ embeds: [embed] });
    await message.react('👍🏻');
  } catch (error) {
    console.error('Error in info command:', error);
    await message.react('👎🏻');
  }
}

// !annulla - Cancel the last command
async function commandAnnulla(message: Message, commandParts: string[]) {
  try {
    // Default to 1 command if not specified
    const count = commandParts.length > 1 ? parseInt(commandParts[1]) : 1;
    
    if (isNaN(count) || count <= 0) {
      await message.reply('Il numero di comandi da annullare deve essere un numero positivo.');
      await message.react('❓');
      return;
    }

    // Get the last command logs for this channel
    const logs = await storage.getLastCommandLogs(
      message.channelId, 
      message.guildId || 'DM', 
      count
    );

    if (logs.length === 0) {
      await message.reply('Non ci sono comandi da annullare.');
      await message.react('❓');
      return;
    }

    // Undo the commands
    const undoResults = [];
    for (const log of logs) {
      // Undo based on command type
      const logParts = log.command.split(' ');
      const cmdType = logParts[0].toLowerCase();

      let undoResult: string;
      
      switch (cmdType) {
        case '!entra':
          // To undo an !entra, we need to remove those troops
          if (log.affectedData) {
            const affected = log.affectedData as any;
            undoResult = await storage.undoTroopAddition(
              message.channelId,
              message.guildId || 'DM',
              affected
            );
          } else {
            undoResult = "Dati insufficienti per annullare il comando";
          }
          break;
        case '!esci':
          // To undo an !esci, we need to add those troops back
          if (log.affectedData) {
            const affected = log.affectedData as any;
            undoResult = await storage.undoTroopRemoval(
              message.channelId,
              message.guildId || 'DM',
              affected
            );
          } else {
            undoResult = "Dati insufficienti per annullare il comando";
          }
          break;
        case '!sposta':
          // To undo a !sposta, we need to move troops back
          if (log.affectedData) {
            const affected = log.affectedData as any;
            undoResult = await storage.undoTroopMovement(
              message.channelId,
              message.guildId || 'DM',
              affected
            );
          } else {
            undoResult = "Dati insufficienti per annullare il comando";
          }
          break;
        case '!svuota':
          // Not possible to undo a !svuota command unless we have a backup
          if (log.affectedData) {
            const affected = log.affectedData as any;
            undoResult = await storage.undoCityClearing(
              message.channelId,
              message.guildId || 'DM',
              affected
            );
          } else {
            undoResult = "Impossibile annullare lo svuotamento della città";
          }
          break;
        default:
          undoResult = `Comando ${cmdType} non può essere annullato`;
      }
      
      undoResults.push(`Annullato: ${log.command} - ${undoResult}`);
    }
    
    await message.reply(`Ho annullato ${logs.length} comando/i:\n${undoResults.join('\n')}`);
    await message.react('👍🏻');
  } catch (error) {
    console.error('Error in annulla command:', error);
    await message.react('👎🏻');
    await message.reply('Si è verificato un errore durante l\'annullamento dei comandi.');
  }
}

// !stop - Restart the bot (admin only)
async function commandStop(message: Message) {
  try {
    // Check if user is an admin
    const isUserAdmin = await isAdmin(message.author.id, message.channelId, message.guildId || 'DM');
    
    if (!isUserAdmin) {
      await message.reply('Solo gli amministratori possono riavviare il bot.');
      await message.react('👎🏻');
      return;
    }

    await message.reply('Riavvio del bot in corso...');
    await message.react('👍🏻');
    
    // In a real bot, you would restart the bot process here
    // For this implementation, we'll just simulate a restart
    setTimeout(() => {
      message.channel.send('TruppArdito è di nuovo online e operativo! ✅');
    }, 3000);
  } catch (error) {
    console.error('Error in stop command:', error);
    await message.react('👎🏻');
  }
}

// !entra - Register troop entry
async function commandEntra(message: Message, commandParts: string[]) {
  try {
    if (commandParts.length < 5) {
      await message.reply('Comando non valido. Uso corretto: !entra [quantità] [tipo truppa] [nazione] [città]');
      await message.react('❓');
      return;
    }

    const quantity = parseInt(commandParts[1]);
    if (isNaN(quantity) || quantity <= 0) {
      await message.reply('La quantità deve essere un numero positivo.');
      await message.react('❓');
      return;
    }

    const troopType = standardizeTroopType(commandParts[2]);
    const nation = standardizeNation(commandParts[3]);
    const city = commandParts.slice(4).join(' ').toLowerCase();

    // Validate troop type and nation
    if (!standardTroopTypesEnum.safeParse(troopType).success) {
      await message.reply(`Tipo di truppa non valido: ${commandParts[2]}. Tipi validi: fanti, cavalli, blindi, dirigibili, artiglierie.`);
      await message.react('❓');
      return;
    }

    if (!standardNationNamesEnum.safeParse(nation).success) {
      await message.reply(`Nazione non valida: ${commandParts[3]}. Nazioni valide: svezia, russia, germania, austria, turchia, italia, gran bretagna, francia, spagna, marocco.`);
      await message.react('❓');
      return;
    }

    // Add troops to the database
    const troopData = {
      channelId: message.channelId,
      serverId: message.guildId || 'DM',
      troopType,
      nation,
      city,
      quantity,
      updatedAt: new Date().toISOString(),
      updatedBy: message.author.id
    };

    // Store data about this operation for potential undo
    const affectedData = {
      troopType,
      nation,
      city,
      quantity
    };

    // Update the command log with the affected data
    await storage.updateLastCommandLog(
      message.channelId,
      message.guildId || 'DM',
      message.author.id,
      affectedData
    );

    // Add the troops
    await storage.addTroops(troopData);

    await message.reply(`Ho aggiunto ${quantity} ${getTroopEmoji(troopType)} ${troopType} della ${getNationEmoji(nation)} ${nation} a ${city}.`);
    await message.react('👍🏻');
  } catch (error) {
    console.error('Error in entra command:', error);
    await message.react('👎🏻');
    await message.reply('Si è verificato un errore durante l\'aggiunta delle truppe.');
  }
}

// !esci - Register troop exit
async function commandEsci(message: Message, commandParts: string[]) {
  try {
    if (commandParts.length < 5) {
      await message.reply('Comando non valido. Uso corretto: !esci [quantità] [tipo truppa] [nazione] [città]');
      await message.react('❓');
      return;
    }

    const quantity = parseInt(commandParts[1]);
    if (isNaN(quantity) || quantity <= 0) {
      await message.reply('La quantità deve essere un numero positivo.');
      await message.react('❓');
      return;
    }

    const troopType = standardizeTroopType(commandParts[2]);
    const nation = standardizeNation(commandParts[3]);
    const city = commandParts.slice(4).join(' ').toLowerCase();

    // Validate troop type and nation
    if (!standardTroopTypesEnum.safeParse(troopType).success) {
      await message.reply(`Tipo di truppa non valido: ${commandParts[2]}. Tipi validi: fanti, cavalli, blindi, dirigibili, artiglierie.`);
      await message.react('❓');
      return;
    }

    if (!standardNationNamesEnum.safeParse(nation).success) {
      await message.reply(`Nazione non valida: ${commandParts[3]}. Nazioni valide: svezia, russia, germania, austria, turchia, italia, gran bretagna, francia, spagna, marocco.`);
      await message.react('❓');
      return;
    }

    // Check if there are enough troops to remove
    const existingTroops = await storage.getTroopsByTypeNationCity(
      message.channelId,
      message.guildId || 'DM',
      troopType,
      nation,
      city
    );

    if (!existingTroops || existingTroops.quantity < quantity) {
      await message.reply(`Non ci sono abbastanza ${troopType} della ${nation} a ${city} da rimuovere.`);
      await message.react('❓');
      return;
    }

    // Store data about this operation for potential undo
    const affectedData = {
      troopType,
      nation,
      city,
      quantity,
      existingQuantity: existingTroops.quantity
    };

    // Update the command log with the affected data
    await storage.updateLastCommandLog(
      message.channelId,
      message.guildId || 'DM',
      message.author.id,
      affectedData
    );

    // Remove the troops
    await storage.removeTroops(
      message.channelId,
      message.guildId || 'DM',
      troopType,
      nation,
      city,
      quantity,
      message.author.id
    );

    await message.reply(`Ho rimosso ${quantity} ${getTroopEmoji(troopType)} ${troopType} della ${getNationEmoji(nation)} ${nation} da ${city}.`);
    await message.react('👍🏻');
  } catch (error) {
    console.error('Error in esci command:', error);
    await message.react('👎🏻');
    await message.reply('Si è verificato un errore durante la rimozione delle truppe.');
  }
}

// !sposta - Move troops between cities
async function commandSposta(message: Message, commandParts: string[]) {
  try {
    if (commandParts.length < 6) {
      await message.reply('Comando non valido. Uso corretto: !sposta [quantità] [tipo truppa] [nazione] [città origine] [città destinazione]');
      await message.react('❓');
      return;
    }

    const quantity = parseInt(commandParts[1]);
    if (isNaN(quantity) || quantity <= 0) {
      await message.reply('La quantità deve essere un numero positivo.');
      await message.react('❓');
      return;
    }

    const troopType = standardizeTroopType(commandParts[2]);
    const nation = standardizeNation(commandParts[3]);
    
    // Extract the source and destination cities
    // We need to determine where one city name ends and another begins
    // This is tricky as city names might contain spaces
    
    // First, join all remaining parts
    const remainingText = commandParts.slice(4).join(' ').toLowerCase();
    
    // Try to split it sensibly
    // Let's assume the user puts a comma, 'a', or 'to' between cities
    let sourceCity, destCity;
    
    if (remainingText.includes(',')) {
      [sourceCity, destCity] = remainingText.split(',').map(s => s.trim());
    } else if (remainingText.includes(' a ')) {
      [sourceCity, destCity] = remainingText.split(' a ').map(s => s.trim());
    } else if (remainingText.includes(' to ')) {
      [sourceCity, destCity] = remainingText.split(' to ').map(s => s.trim());
    } else {
      // If no clear separator, assume the last word is the destination
      const parts = remainingText.split(' ');
      destCity = parts.pop() || '';
      sourceCity = parts.join(' ');
    }

    if (!sourceCity || !destCity) {
      await message.reply('Non riesco a capire le città di origine e destinazione. Prova ad usare una virgola tra le due città.');
      await message.react('❓');
      return;
    }

    // Validate troop type and nation
    if (!standardTroopTypesEnum.safeParse(troopType).success) {
      await message.reply(`Tipo di truppa non valido: ${commandParts[2]}. Tipi validi: fanti, cavalli, blindi, dirigibili, artiglierie.`);
      await message.react('❓');
      return;
    }

    if (!standardNationNamesEnum.safeParse(nation).success) {
      await message.reply(`Nazione non valida: ${commandParts[3]}. Nazioni valide: svezia, russia, germania, austria, turchia, italia, gran bretagna, francia, spagna, marocco.`);
      await message.react('❓');
      return;
    }

    // Check if there are enough troops to move
    const existingTroops = await storage.getTroopsByTypeNationCity(
      message.channelId,
      message.guildId || 'DM',
      troopType,
      nation,
      sourceCity
    );

    if (!existingTroops || existingTroops.quantity < quantity) {
      await message.reply(`Non ci sono abbastanza ${troopType} della ${nation} a ${sourceCity} da spostare.`);
      await message.react('❓');
      return;
    }

    // Store data about this operation for potential undo
    const affectedData = {
      troopType,
      nation,
      sourceCity,
      destCity,
      quantity,
      existingQuantitySource: existingTroops.quantity
    };

    // Update the command log with the affected data
    await storage.updateLastCommandLog(
      message.channelId,
      message.guildId || 'DM',
      message.author.id,
      affectedData
    );

    // Move the troops
    await storage.moveTroops(
      message.channelId,
      message.guildId || 'DM',
      troopType,
      nation,
      sourceCity,
      destCity,
      quantity,
      message.author.id
    );

    await message.reply(`Ho spostato ${quantity} ${getTroopEmoji(troopType)} ${troopType} della ${getNationEmoji(nation)} ${nation} da ${sourceCity} a ${destCity}.`);
    await message.react('👍🏻');
  } catch (error) {
    console.error('Error in sposta command:', error);
    await message.react('👎🏻');
    await message.reply('Si è verificato un errore durante lo spostamento delle truppe.');
  }
}

// !svuota - Clear all troops from a city
async function commandSvuota(message: Message, commandParts: string[]) {
  try {
    if (commandParts.length < 2) {
      await message.reply('Comando non valido. Uso corretto: !svuota [città]');
      await message.react('❓');
      return;
    }

    const city = commandParts.slice(1).join(' ').toLowerCase();

    // Get all troops in the city for backup
    const existingTroops = await storage.getTroopsByCity(
      message.channelId,
      message.guildId || 'DM',
      city
    );

    if (existingTroops.length === 0) {
      await message.reply(`Non ci sono truppe nella città di ${city}.`);
      await message.react('❓');
      return;
    }

    // Store data about this operation for potential undo
    const affectedData = {
      city,
      troops: existingTroops
    };

    // Update the command log with the affected data
    await storage.updateLastCommandLog(
      message.channelId,
      message.guildId || 'DM',
      message.author.id,
      affectedData
    );

    // Clear all troops from the city
    await storage.clearCity(
      message.channelId,
      message.guildId || 'DM',
      city,
      message.author.id
    );

    await message.reply(`Ho rimosso tutte le truppe dalla città di ${city}.`);
    await message.react('👍🏻');
  } catch (error) {
    console.error('Error in svuota command:', error);
    await message.react('👎🏻');
    await message.reply('Si è verificato un errore durante lo svuotamento della città.');
  }
}

// !totale - Show troops in a city
async function commandTotale(message: Message, commandParts: string[]) {
  try {
    if (commandParts.length < 2) {
      await message.reply('Comando non valido. Uso corretto: !totale [città]');
      await message.react('❓');
      return;
    }

    const city = commandParts.slice(1).join(' ').toLowerCase();

    // Get troops in the city
    const troops = await storage.getTroopsByCity(
      message.channelId,
      message.guildId || 'DM',
      city
    );

    if (troops.length === 0) {
      await message.reply(`Non ci sono truppe nella città di ${city}.`);
      await message.react('ℹ️');
      return;
    }

    // Group troops by nation
    const troopsByNation = new Map<string, Array<{ type: string, quantity: number }>>();
    
    for (const troop of troops) {
      if (!troopsByNation.has(troop.nation)) {
        troopsByNation.set(troop.nation, []);
      }
      troopsByNation.get(troop.nation)?.push({
        type: troop.troopType,
        quantity: troop.quantity
      });
    }

    // Build the response
    let response = `📊 Truppe presenti a ${city}:\n\n`;
    
    for (const [nation, nationTroops] of troopsByNation.entries()) {
      response += `${getNationEmoji(nation)} **${nation.charAt(0).toUpperCase() + nation.slice(1)}**:\n`;
      
      for (const troop of nationTroops) {
        response += `- ${troop.quantity} ${getTroopEmoji(troop.type)} ${troop.type}\n`;
      }
      
      response += '\n';
    }

    await message.reply(response);
    await message.react('ℹ️');
  } catch (error) {
    console.error('Error in totale command:', error);
    await message.react('👎🏻');
    await message.reply('Si è verificato un errore durante il recupero delle truppe.');
  }
}

// !totalenazione - Show troops by nation
async function commandTotaleNazione(message: Message, commandParts: string[]) {
  try {
    if (commandParts.length < 2) {
      await message.reply('Comando non valido. Uso corretto: !totalenazione [nazione]');
      await message.react('❓');
      return;
    }

    const nationInput = commandParts.slice(1).join(' ');
    const nation = standardizeNation(nationInput);

    // Validate nation
    if (!standardNationNamesEnum.safeParse(nation).success) {
      await message.reply(`Nazione non valida: ${nationInput}. Nazioni valide: svezia, russia, germania, austria, turchia, italia, gran bretagna, francia, spagna, marocco.`);
      await message.react('❓');
      return;
    }

    // Get troops for the nation
    const troops = await storage.getTroopsByNation(
      message.channelId,
      message.guildId || 'DM',
      nation
    );

    if (troops.length === 0) {
      await message.reply(`Non ci sono truppe della nazione ${nation}.`);
      await message.react('ℹ️');
      return;
    }

    // Group troops by city
    const troopsByCity = new Map<string, Array<{ type: string, quantity: number }>>();
    
    for (const troop of troops) {
      if (!troopsByCity.has(troop.city)) {
        troopsByCity.set(troop.city, []);
      }
      troopsByCity.get(troop.city)?.push({
        type: troop.troopType,
        quantity: troop.quantity
      });
    }

    // Build the response
    let response = `📊 Truppe della ${getNationEmoji(nation)} **${nation.charAt(0).toUpperCase() + nation.slice(1)}**:\n\n`;
    
    for (const [city, cityTroops] of troopsByCity.entries()) {
      response += `**${city.charAt(0).toUpperCase() + city.slice(1)}**:\n`;
      
      for (const troop of cityTroops) {
        response += `- ${troop.quantity} ${getTroopEmoji(troop.type)} ${troop.type}\n`;
      }
      
      response += '\n';
    }

    await message.reply(response);
    await message.react('ℹ️');
  } catch (error) {
    console.error('Error in totalenazione command:', error);
    await message.react('👎🏻');
    await message.reply('Si è verificato un errore durante il recupero delle truppe.');
  }
}

// !lista - Show list of cities
async function commandLista(message: Message) {
  try {
    // Get all cities
    const cities = await storage.getAllCities(
      message.channelId,
      message.guildId || 'DM'
    );

    if (cities.length === 0) {
      await message.reply('Non ci sono città registrate.');
      await message.react('ℹ️');
      return;
    }

    // Build the response
    let response = '📍 **Città registrate**:\n\n';
    
    for (const city of cities) {
      response += `- ${city.charAt(0).toUpperCase() + city.slice(1)}\n`;
    }

    await message.reply(response);
    await message.react('ℹ️');
  } catch (error) {
    console.error('Error in lista command:', error);
    await message.react('👎🏻');
    await message.reply('Si è verificato un errore durante il recupero delle città.');
  }
}

// !azzera - Clear all data (admin only)
async function commandAzzera(message: Message) {
  try {
    // Check if user is an admin
    const isUserAdmin = await isAdmin(message.author.id, message.channelId, message.guildId || 'DM');
    
    if (!isUserAdmin && !message.member?.permissions.has('Administrator')) {
      await message.reply('Solo gli amministratori possono azzerare i dati.');
      await message.react('👎🏻');
      return;
    }

    // Ask for confirmation
    await message.reply(`⚠️ ${message.author}, sei sicuro di voler eliminare tutti i dati? Rispondi con 'SI' per confermare o 'NO' per annullare.`);
    
    // We'll use a simpler approach with direct message monitoring
    
    // Create a filter function for messages
    const filter = (m: Message) => {
      return m.author.id === message.author.id && 
            (m.content.toUpperCase() === 'SI' || m.content.toUpperCase() === 'NO');
    };
    
    try {
      // Send a follow-up message directly asking for confirmation
      await message.channel.send(`${message.author}, scrivi "SI" per confermare o "NO" per annullare l'azzeramento dei dati.`);
      
      // Direct approach using a message collector
      const collector = message.channel.createMessageCollector({
        filter: msg => 
          msg.author.id === message.author.id && 
          (msg.content.toUpperCase() === 'SI' || msg.content.toUpperCase() === 'NO'),
        time: 30000,
        max: 1
      });
      
      // Set up a promise to handle the result
      await new Promise<void>((resolve) => {
        collector.on('collect', async (response) => {
          if (response.content.toUpperCase() === 'SI') {
            // User confirmed, clear the troops
            await storage.clearTroopsForChannel(message.channelId, message.guildId || 'DM');
            await message.reply('Dati azzerati con successo! 🗑️');
          } else {
            // User cancelled
            await message.reply('Operazione annullata.');
          }
          resolve();
        });
        
        collector.on('end', collected => {
          if (collected.size === 0) {
            // No response received
            message.reply('Tempo scaduto. L\'operazione è stata annullata.');
          }
          resolve();
        });
      });
    } catch (error) {
      console.error('Error during confirmation:', error);
      await message.reply('Si è verificato un errore durante l\'azzeramento. Riprova più tardi.');
    }
    
  } catch (error) {
    console.error('Error in azzera command:', error);
    await message.react('👎🏻');
    await message.reply('Si è verificato un errore durante l\'azzeramento dei dati.');
  }
}

// !admin - Admin panel
async function commandAdmin(message: Message) {
  try {
    const parts = message.content.split(' ');
    const subCommand = parts[1]?.toLowerCase(); // add, remove, o nessuno
    const userMention = parts[2]; // menzione dell'utente @nome
    
    // Il proprietario del bot ha sempre permessi di amministratore
    const isBotOwner = message.author.id === process.env.BOT_OWNER_ID;
    
    // Controllare se l'utente è un amministratore
    let isUserAdmin = await isAdmin(message.author.id, message.channelId, message.guildId || 'DM');
    
    // Il proprietario del server ha sempre permessi di amministratore
    const isServerOwner = message.guild?.ownerId === message.author.id;
    
    // Se l'utente ha permessi di amministrazione Discord
    const hasAdminPermissions = message.member?.permissions.has('Administrator');
    
    // Verifica se l'utente può eseguire comandi admin
    const canPerformAdminActions = isBotOwner || isUserAdmin || isServerOwner || hasAdminPermissions;
    
    // Gestione sottocomandi
    if (subCommand === 'add' && userMention) {
      if (!canPerformAdminActions) {
        await message.reply('Non hai i permessi per aggiungere amministratori.');
        await message.react('👎🏻');
        return;
      }
      
      // Estrarre l'ID utente dalla menzione (formato <@ID> o <@!ID>)
      const userId = userMention.replace(/[<@!>]/g, '');
      
      if (!userId || userId.length < 5) {
        await message.reply('Formato utente non valido. Usa @utente per menzionare l\'utente che vuoi aggiungere.');
        await message.react('❓');
        return;
      }
      
      // Verificare se l'utente è già un amministratore
      const admins = await storage.getChannelAdmins(message.channelId, message.guildId || 'DM');
      const isAlreadyAdmin = admins.some(admin => admin.adminId === userId);
      
      if (isAlreadyAdmin) {
        await message.reply(`L'utente <@${userId}> è già un amministratore.`);
        await message.react('⚠️');
        return;
      }
      
      // Aggiungere l'utente come amministratore
      await storage.addChannelAdmin({
        channelId: message.channelId,
        serverId: message.guildId || 'DM',
        adminId: userId,
        addedBy: message.author.id,
        addedAt: new Date().toISOString()
      });
      
      await message.reply(`L'utente <@${userId}> è stato aggiunto come amministratore.`);
      await message.react('✅');
      return;
    }
    
    if (subCommand === 'remove' && userMention) {
      if (!canPerformAdminActions) {
        await message.reply('Non hai i permessi per rimuovere amministratori.');
        await message.react('👎🏻');
        return;
      }
      
      // Estrarre l'ID utente dalla menzione
      const userId = userMention.replace(/[<@!>]/g, '');
      
      if (!userId || userId.length < 5) {
        await message.reply('Formato utente non valido. Usa @utente per menzionare l\'utente che vuoi rimuovere.');
        await message.react('❓');
        return;
      }
      
      // Verificare se l'utente è un amministratore
      const admins = await storage.getChannelAdmins(message.channelId, message.guildId || 'DM');
      const isAdmin = admins.some(admin => admin.adminId === userId);
      
      if (!isAdmin) {
        await message.reply(`L'utente <@${userId}> non è un amministratore.`);
        await message.react('⚠️');
        return;
      }
      
      // Rimuovere l'utente come amministratore
      await storage.removeChannelAdmin(message.channelId, message.guildId || 'DM', userId);
      
      await message.reply(`L'utente <@${userId}> è stato rimosso dagli amministratori.`);
      await message.react('✅');
      return;
    }
    
    // Se l'utente non è un amministratore e non ha permessi di amministrazione
    if (!canPerformAdminActions) {
      await message.reply('Solo gli amministratori possono accedere al pannello admin.');
      await message.react('👎🏻');
      return;
    }

    // Get current admins for this channel
    const admins = await storage.getChannelAdmins(
      message.channelId,
      message.guildId || 'DM'
    );

    // Create embed for admin panel
    const embed = new EmbedBuilder()
      .setTitle('🔐 Pannello Amministratore')
      .setColor('#4A5568')
      .setDescription('Amministratori del canale corrente:');

    // Add current admins to the embed
    if (admins.length === 0) {
      embed.addFields({ name: 'Nessun amministratore', value: 'Usa !admin add @utente per aggiungere amministratori.' });
    } else {
      let adminList = '';
      for (const admin of admins) {
        adminList += `<@${admin.adminId}>\n`;
      }
      embed.addFields({ name: 'Amministratori', value: adminList });
    }

    // Add instruction fields
    embed.addFields(
      { name: 'Aggiungi Admin', value: '!admin add @utente', inline: true },
      { name: 'Rimuovi Admin', value: '!admin remove @utente', inline: true }
    );

    // Informazioni sul proprietario del bot
    if (process.env.BOT_OWNER_ID) {
      embed.addFields({ 
        name: 'Proprietario Bot', 
        value: `<@${process.env.BOT_OWNER_ID}> (ha sempre accesso amministrativo)` 
      });
    }

    await message.reply({ embeds: [embed] });
    await message.react('👍🏻');
  } catch (error) {
    console.error('Error in admin command:', error);
    await message.react('👎🏻');
    await message.reply('Si è verificato un errore durante l\'accesso al pannello admin.');
  }
}

// !ping - Test bot responsiveness
async function commandPing(message: Message) {
  try {
    const sent = await message.reply('Pong!');
    const ping = sent.createdTimestamp - message.createdTimestamp;
    
    await sent.edit(`Pong! Latenza: ${ping}ms | API: ${message.client.ws.ping}ms`);
    await message.react('👍🏻');
  } catch (error) {
    console.error('Error in ping command:', error);
    await message.react('👎🏻');
  }
}
