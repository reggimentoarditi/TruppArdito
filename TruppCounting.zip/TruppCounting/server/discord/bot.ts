import { Client, GatewayIntentBits, Events, Message, MessageReaction, PartialMessageReaction, PartialUser, User } from 'discord.js';
import { config } from 'dotenv';
import { handleCommand } from './commands';
import { storage } from '../storage';
import { log } from '../vite';

// Load environment variables
config();

// Set up Discord client with necessary intents
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
  ],
});

// Initialize bot
export async function initializeBot() {
  if (!process.env.DISCORD_TOKEN) {
    log('Missing DISCORD_TOKEN environment variable', 'discord');
    return null;
  }

  // Bot ready event
  client.once(Events.ClientReady, (c) => {
    log(`Bot logged in as ${c.user.tag}`, 'discord');
  });

  // Handle messages
  client.on(Events.MessageCreate, async (message: Message) => {
    // Ignore messages from bots
    if (message.author.bot) return;

    // Check if message starts with command prefix
    if (message.content.startsWith('!')) {
      try {
        await handleCommand(message);
      } catch (error) {
        console.error('Error handling command:', error);
        await message.react('❓');
        await message.reply('Si è verificato un errore durante l\'elaborazione del comando. Riprova più tardi.');
      }
    }
  });

  // Removed reaction handler for !azzera command as it now uses direct message responses

  // Login to Discord
  try {
    await client.login(process.env.DISCORD_TOKEN);
    return client;
  } catch (error) {
    log(`Error connecting to Discord: ${error}`, 'discord');
    return null;
  }
}

// Get status of the bot
export function getBotStatus(): { online: boolean; latency: number | null } {
  return {
    online: client.isReady(),
    latency: client.ws.ping,
  };
}

// Shutdown bot
export async function shutdownBot() {
  if (client) {
    client.destroy();
    log('Bot disconnected', 'discord');
  }
}
