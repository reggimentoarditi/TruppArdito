import {
  User,
  InsertUser,
  Troop,
  InsertTroop,
  CommandLog,
  InsertCommandLog,
  ChannelAdmin,
  InsertChannelAdmin
} from '@shared/schema';

// Interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Troop operations
  addTroops(troop: InsertTroop): Promise<void>;
  removeTroops(channelId: string, serverId: string, troopType: string, nation: string, city: string, quantity: number, userId: string): Promise<void>;
  moveTroops(channelId: string, serverId: string, troopType: string, nation: string, sourceCity: string, destCity: string, quantity: number, userId: string): Promise<void>;
  clearCity(channelId: string, serverId: string, city: string, userId: string): Promise<void>;
  getTroopsByCity(channelId: string, serverId: string, city: string): Promise<Troop[]>;
  getTroopsByNation(channelId: string, serverId: string, nation: string): Promise<Troop[]>;
  getTroopsByTypeNationCity(channelId: string, serverId: string, troopType: string, nation: string, city: string): Promise<Troop | undefined>;
  getAllCities(channelId: string, serverId: string): Promise<string[]>;
  clearTroopsForChannel(channelId: string, serverId: string): Promise<void>;
  
  // Command log operations
  logCommand(log: InsertCommandLog): Promise<void>;
  updateLastCommandLog(channelId: string, serverId: string, userId: string, affectedData: any): Promise<void>;
  getLastCommandLogs(channelId: string, serverId: string, count: number): Promise<CommandLog[]>;
  
  // Admin operations
  addChannelAdmin(admin: InsertChannelAdmin): Promise<void>;
  removeChannelAdmin(channelId: string, serverId: string, adminId: string): Promise<void>;
  getChannelAdmins(channelId: string, serverId: string): Promise<ChannelAdmin[]>;
  
  // Undo operations
  undoTroopAddition(channelId: string, serverId: string, data: any): Promise<string>;
  undoTroopRemoval(channelId: string, serverId: string, data: any): Promise<string>;
  undoTroopMovement(channelId: string, serverId: string, data: any): Promise<string>;
  undoCityClearing(channelId: string, serverId: string, data: any): Promise<string>;
  
  // System operations
  checkDatabaseConnection(): Promise<boolean>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private troops: Map<string, Troop>;  // Key is channelId:serverId:troopType:nation:city
  private commandLogs: CommandLog[];
  private channelAdmins: Map<string, ChannelAdmin[]>; // Key is channelId:serverId
  private currentUserId: number;
  private currentTroopId: number;
  private currentCommandLogId: number;
  private currentChannelAdminId: number;

  constructor() {
    this.users = new Map();
    this.troops = new Map();
    this.commandLogs = [];
    this.channelAdmins = new Map();
    this.currentUserId = 1;
    this.currentTroopId = 1;
    this.currentCommandLogId = 1;
    this.currentChannelAdminId = 1;
    
    // Initialize with default admin (bot owner)
    if (process.env.BOT_OWNER_ID) {
      this.users.set(1, {
        id: 1,
        username: "owner",
        password: "not-used",
        discordId: process.env.BOT_OWNER_ID,
        isAdmin: true as boolean
      });
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      isAdmin: insertUser.isAdmin ?? false 
    };
    this.users.set(id, user);
    return user;
  }

  // Troop operations
  async addTroops(troop: InsertTroop): Promise<void> {
    const key = `${troop.channelId}:${troop.serverId}:${troop.troopType}:${troop.nation}:${troop.city}`;
    const existingTroop = this.troops.get(key);
    
    if (existingTroop) {
      // Update existing troop
      existingTroop.quantity += troop.quantity;
      existingTroop.updatedAt = troop.updatedAt;
      existingTroop.updatedBy = troop.updatedBy;
    } else {
      // Create new troop
      const id = this.currentTroopId++;
      const newTroop: Troop = { ...troop, id };
      this.troops.set(key, newTroop);
    }
  }

  async removeTroops(
    channelId: string,
    serverId: string,
    troopType: string,
    nation: string,
    city: string,
    quantity: number,
    userId: string
  ): Promise<void> {
    const key = `${channelId}:${serverId}:${troopType}:${nation}:${city}`;
    const existingTroop = this.troops.get(key);
    
    if (!existingTroop) {
      throw new Error(`Non ci sono truppe di tipo ${troopType} della nazione ${nation} nella città ${city}`);
    }
    
    if (existingTroop.quantity < quantity) {
      throw new Error(`Non ci sono abbastanza truppe di tipo ${troopType} della nazione ${nation} nella città ${city}. Attualmente ce ne sono ${existingTroop.quantity}`);
    }
    
    existingTroop.quantity -= quantity;
    existingTroop.updatedAt = new Date().toISOString();
    existingTroop.updatedBy = userId;
    
    // Remove entry if quantity is 0
    if (existingTroop.quantity === 0) {
      this.troops.delete(key);
    }
  }

  async moveTroops(
    channelId: string,
    serverId: string,
    troopType: string,
    nation: string,
    sourceCity: string,
    destCity: string,
    quantity: number,
    userId: string
  ): Promise<void> {
    // Remove from source
    await this.removeTroops(
      channelId,
      serverId,
      troopType,
      nation,
      sourceCity,
      quantity,
      userId
    );
    
    // Add to destination
    await this.addTroops({
      channelId,
      serverId,
      troopType,
      nation,
      city: destCity,
      quantity,
      updatedAt: new Date().toISOString(),
      updatedBy: userId
    });
  }

  async clearCity(
    channelId: string,
    serverId: string,
    city: string,
    userId: string
  ): Promise<void> {
    const troopsToRemove: string[] = [];
    
    // Find all troops in the city
    for (const [key, troop] of this.troops.entries()) {
      if (
        troop.channelId === channelId &&
        troop.serverId === serverId &&
        troop.city.toLowerCase() === city.toLowerCase()
      ) {
        troopsToRemove.push(key);
      }
    }
    
    // Remove all troops
    for (const key of troopsToRemove) {
      this.troops.delete(key);
    }
  }

  async getTroopsByCity(
    channelId: string,
    serverId: string,
    city: string
  ): Promise<Troop[]> {
    const result: Troop[] = [];
    
    for (const troop of this.troops.values()) {
      if (
        troop.channelId === channelId &&
        troop.serverId === serverId &&
        troop.city.toLowerCase() === city.toLowerCase()
      ) {
        result.push({ ...troop });
      }
    }
    
    return result;
  }

  async getTroopsByNation(
    channelId: string,
    serverId: string,
    nation: string
  ): Promise<Troop[]> {
    const result: Troop[] = [];
    
    for (const troop of this.troops.values()) {
      if (
        troop.channelId === channelId &&
        troop.serverId === serverId &&
        troop.nation.toLowerCase() === nation.toLowerCase()
      ) {
        result.push({ ...troop });
      }
    }
    
    return result;
  }

  async getTroopsByTypeNationCity(
    channelId: string,
    serverId: string,
    troopType: string,
    nation: string,
    city: string
  ): Promise<Troop | undefined> {
    const key = `${channelId}:${serverId}:${troopType}:${nation}:${city}`;
    return this.troops.get(key);
  }

  async getAllCities(
    channelId: string,
    serverId: string
  ): Promise<string[]> {
    const cities = new Set<string>();
    
    for (const troop of this.troops.values()) {
      if (
        troop.channelId === channelId &&
        troop.serverId === serverId
      ) {
        cities.add(troop.city.toLowerCase());
      }
    }
    
    return Array.from(cities);
  }

  async clearTroopsForChannel(
    channelId: string,
    serverId: string
  ): Promise<void> {
    const keysToDelete: string[] = [];
    
    for (const [key, troop] of this.troops.entries()) {
      if (
        troop.channelId === channelId &&
        troop.serverId === serverId
      ) {
        keysToDelete.push(key);
      }
    }
    
    for (const key of keysToDelete) {
      this.troops.delete(key);
    }
  }

  // Command log operations
  async logCommand(log: InsertCommandLog): Promise<void> {
    const id = this.currentCommandLogId++;
    const newLog: CommandLog = { ...log, id };
    this.commandLogs.push(newLog);
  }

  async updateLastCommandLog(
    channelId: string,
    serverId: string,
    userId: string,
    affectedData: any
  ): Promise<void> {
    // Find the most recent log for this user in this channel
    const index = this.commandLogs.findIndex(log => 
      log.channelId === channelId &&
      log.serverId === serverId &&
      log.userId === userId
    );
    
    if (index !== -1) {
      this.commandLogs[index].affectedData = affectedData;
    }
  }

  async getLastCommandLogs(
    channelId: string,
    serverId: string,
    count: number
  ): Promise<CommandLog[]> {
    // Get logs for this channel, sorted by most recent first
    const channelLogs = this.commandLogs
      .filter(log => log.channelId === channelId && log.serverId === serverId)
      .sort((a, b) => {
        const dateA = new Date(a.timestamp);
        const dateB = new Date(b.timestamp);
        return dateB.getTime() - dateA.getTime();
      });
    
    // Return the requested number of logs
    return channelLogs.slice(0, count);
  }

  // Admin operations
  async addChannelAdmin(admin: InsertChannelAdmin): Promise<void> {
    const key = `${admin.channelId}:${admin.serverId}`;
    const id = this.currentChannelAdminId++;
    const newAdmin: ChannelAdmin = { ...admin, id };
    
    if (!this.channelAdmins.has(key)) {
      this.channelAdmins.set(key, []);
    }
    
    this.channelAdmins.get(key)?.push(newAdmin);
  }

  async removeChannelAdmin(
    channelId: string,
    serverId: string,
    adminId: string
  ): Promise<void> {
    const key = `${channelId}:${serverId}`;
    const admins = this.channelAdmins.get(key);
    
    if (admins) {
      const index = admins.findIndex(admin => admin.adminId === adminId);
      
      if (index !== -1) {
        admins.splice(index, 1);
      }
    }
  }

  async getChannelAdmins(
    channelId: string,
    serverId: string
  ): Promise<ChannelAdmin[]> {
    const key = `${channelId}:${serverId}`;
    return this.channelAdmins.get(key) || [];
  }

  // Undo operations
  async undoTroopAddition(
    channelId: string,
    serverId: string,
    data: any
  ): Promise<string> {
    try {
      if (!data || !data.troopType || !data.nation || !data.city || !data.quantity) {
        return "Dati insufficienti per annullare l'aggiunta";
      }
      
      // Remove the troops that were added
      await this.removeTroops(
        channelId,
        serverId,
        data.troopType,
        data.nation,
        data.city,
        data.quantity,
        "undo-system"
      );
      
      return "Aggiunta annullata con successo";
    } catch (error) {
      return `Errore: ${(error as Error).message}`;
    }
  }

  async undoTroopRemoval(
    channelId: string,
    serverId: string,
    data: any
  ): Promise<string> {
    try {
      if (!data || !data.troopType || !data.nation || !data.city || !data.quantity) {
        return "Dati insufficienti per annullare la rimozione";
      }
      
      // Add back the troops that were removed
      await this.addTroops({
        channelId,
        serverId,
        troopType: data.troopType,
        nation: data.nation,
        city: data.city,
        quantity: data.quantity,
        updatedAt: new Date().toISOString(),
        updatedBy: "undo-system"
      });
      
      return "Rimozione annullata con successo";
    } catch (error) {
      return `Errore: ${(error as Error).message}`;
    }
  }

  async undoTroopMovement(
    channelId: string,
    serverId: string,
    data: any
  ): Promise<string> {
    try {
      if (!data || !data.troopType || !data.nation || !data.sourceCity || !data.destCity || !data.quantity) {
        return "Dati insufficienti per annullare lo spostamento";
      }
      
      // Move troops back from destination to source
      await this.moveTroops(
        channelId,
        serverId,
        data.troopType,
        data.nation,
        data.destCity,  // Now the source is the previous destination
        data.sourceCity, // Now the destination is the previous source
        data.quantity,
        "undo-system"
      );
      
      return "Spostamento annullato con successo";
    } catch (error) {
      return `Errore: ${(error as Error).message}`;
    }
  }

  async undoCityClearing(
    channelId: string,
    serverId: string,
    data: any
  ): Promise<string> {
    try {
      if (!data || !data.city || !data.troops || !Array.isArray(data.troops)) {
        return "Dati insufficienti per annullare lo svuotamento";
      }
      
      // Add back all troops that were in the city
      for (const troop of data.troops) {
        await this.addTroops({
          channelId,
          serverId,
          troopType: troop.troopType,
          nation: troop.nation,
          city: troop.city,
          quantity: troop.quantity,
          updatedAt: new Date().toISOString(),
          updatedBy: "undo-system"
        });
      }
      
      return "Svuotamento annullato con successo";
    } catch (error) {
      return `Errore: ${(error as Error).message}`;
    }
  }

  // System operations
  async checkDatabaseConnection(): Promise<boolean> {
    // For in-memory storage, always return true
    return true;
  }
}

// Import database storage implementation
import { DatabaseStorage } from './database-storage';

// Export a singleton instance
export const storage = new DatabaseStorage();
